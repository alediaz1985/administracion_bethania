from django.apps import AppConfig


class AdministracionAlumnosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.administracion_alumnos'
